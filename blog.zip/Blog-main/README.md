# Blog
Blog from practice
